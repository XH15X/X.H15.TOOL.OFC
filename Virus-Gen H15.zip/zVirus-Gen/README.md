# zVirus Gen [![Current Version ](https://img.shields.io/badge/Current%20Version-1.1-blue?style=flat-square)](https://github.com/ZechBron/zVirus-Gen)
Those who don't know how to use VCRT. You can automatically generate a virus.

---

# Next Update Version 1.4
## Features
Will be converted into python 3
+ Choose Api Share

   Bashuploads

   Filepush
   
   Transfer.sh
   
   Anonfiles

+ Bat with Exe for deskop app.

+ I will include my dark programs

Because of consecutive storm here in our country. The update will on February


![zVirus Created By: Zech Bron](https://raw.githubusercontent.com/ZechBron/zVirus-Gen/zVirus/IMG_20200927_175911.png)

## What does `z Virus` Actually do?
Well __Z Virus__ is a Collection of ready made Viruses.
In other Virus Generator tools like let's say vbug, or vcrt. It generate apk virus and you have to manually send it to your victim.
However in __Z Virus__ All you have to do is to send the __link__ to your victim and make the victim download the virus. 


## Install this first:
__Ubuntu__
> apt-get install git -y

__Termux__
> pkg install git -y

__Other__
> apt install git -y


## Installation:
> git clone https://github.com/ZechBron/zVirus-Gen

> cd zVirus-Gen

> chmod +x setup.sh

> ./setup.sh


## To Run:
> ./zVirus

__Or__

> bash zVirus


## To Update
> ./update.sh

__Or__

> bash update.sh

### Note:
Version 1.4 will be posted this 2nd week of February 2021
